# fhir.education.kursig#0.1.0: Moas Kurs-IG

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Test Encounter profil](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Moas Kurs-IG](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
